<ul>
  <li><a href="javascript:load_content('projects')">Projects List</a></li>
  <li><a href="javascript:load_content('projects/add')">Add Project</a></li>
  <li><a href="javascript:load_content('units/add')">Add Unit</a></li>
  <li><a href="javascript:load_content('users')">Manage Users</a></li>
  <li><a href="javascript:load_content('users/add')">Add User</a></li>
</ul>
