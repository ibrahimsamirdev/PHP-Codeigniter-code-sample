<?php
//this condition to add page tags for dreamweaver preview only
if(0){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<link href="../../css/styles.css" rel="stylesheet" type="text/css" />
<body>
<?php
}
?>
<div class="form_block" id="warning" style="margin-top:100px">
  <div class="form_title">Warning</div>
  <div class="form">
  <br /><?=$msg?><br />
    <br />
  </div>
</div>
<?php
if(0){
?>
</body>
</html>
<?php
}
?>
