<div id="loading">
	<div style="display:none">
	  <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="26" height="26">
        <param name="movie" value="flash/f_loader.swf" />
        <param name="quality" value="high" />
		<param name="wmode" value="opaque" /><param name="BGCOLOR" value="dddddd" />
        <embed src="flash/f_loader.swf" width="26" height="26" quality="high" wmode="opaque" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" bgcolor="dddddd"></embed>
      </object>
	</div>
</div>