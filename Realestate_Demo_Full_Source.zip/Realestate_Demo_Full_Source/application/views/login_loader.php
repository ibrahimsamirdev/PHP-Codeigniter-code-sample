<?php $this->load->view("header"); ?>
<div style="height:80px"></div>
<?php $this->load->view($main_content); ?>
<?php $this->load->view("footer"); ?>
